# php_website_basic!
PHP Web site basic, login and sign up and posts board 

posts board is writing, reading, searching, file uploading and downloading 

database schema in git-hub is to be updated soon, refer to my tstory in korean

sorry for upload file func and page isnot writed absolute path

please change ur code corretly path (refer to C:\xampp\htdocs\somefile\PHPweb path)

posts board can access only logined user

&#128549; Sorry for this program about spagetti code &#127837;
programmer is newbie... 


## Using About
* Porject Time : About 3 days

* Language : PHP, HTML, SQL

* HTML Contents just Korean

* Database : mySQL

* Server : Apache

* Tool & Environment : chat GPT (AI Intelligence),  human intelligence(It's me), VsCode, XAMPP
## Data base data & E-R diagram

![image](https://github.com/silver-liq9118/KDT_Simulated_Hacking_Site/assets/68416184/fbfccf6a-91c4-4626-9010-797809742c89)
![image](https://github.com/silver-liq9118/KDT_Simulated_Hacking_Site/assets/68416184/b323fd01-bf4e-4b89-ac12-1e97ec01f675)
![image](https://github.com/silver-liq9118/KDT_Simulated_Hacking_Site/assets/68416184/0ce0cdb5-cd70-4fbe-a6e2-e7038e90bfce)
![image](https://github.com/silver-liq9118/KDT_Simulated_Hacking_Site/assets/68416184/cf75d1ae-8c60-4a06-a072-2930590ac6e1)

![image](https://github.com/silver-liq9118/KDT_Simulated_Hacking_Site/assets/68416184/16d70c41-8a21-425d-8e38-abf577a08222)

More information in just korean tstory blog url
1. [Environment building & Login](https://silver-liq9118.tistory.com/entry/Project-%ED%95%9C%EA%B1%B8%EC%9D%8C%EB%B6%80%ED%84%B0-%EB%8B%A4%EC%8B%9C-%EC%8B%9C%EC%9E%91%ED%95%98%EA%B8%B0-%EC%82%AC%EC%9A%A9%EC%9E%90-%EC%82%AC%EC%9D%B4%ED%8A%B8-%EA%B5%AC%EC%B6%95-PHP-1-%ED%99%98%EA%B2%BD-%EA%B5%AC%EC%B6%95-%EB%B6%80%ED%84%B0-%EB%A1%9C%EA%B7%B8%EC%9D%B8%EA%B9%8C%EC%A7%80)
2. [Join](https://silver-liq9118.tistory.com/entry/Project-%EC%82%AC%EC%9A%A9%EC%9E%90-%EC%82%AC%EC%9D%B4%ED%8A%B8-%EA%B5%AC%EC%B6%95-PHP-2-%ED%9A%8C%EC%9B%90%EA%B0%80%EC%9E%85)
3. [Post board ( board and post write )](https://silver-liq9118.tistory.com/entry/Project-%EC%82%AC%EC%9A%A9%EC%9E%90-%EC%82%AC%EC%9D%B4%ED%8A%B8-%EA%B5%AC%EC%B6%95-PHP-3-%EA%B2%8C%EC%8B%9C%ED%8C%90-%EB%A9%94%EC%9D%B8-%ED%8E%98%EC%9D%B4%EC%A7%80-%EB%B0%8F-%EC%93%B0%EA%B8%B0)

---


# php_기초_웹사이트 입니다!

PHP 웹 사이트 기본으로 로그인 기능과 회원가입 기능이 있습니다.
posts board 글쓰기 기능과 글 읽기 기능, 글 찾기, 파일업로딩등 다운로드등이있습니다.
하지만 파일 업로딩 기능은 모두 상대경로로 작성되었으므로, 꼭 파일 패스를 확인하세요!

(참조 상대경로 C:\xampp\htdocs\somefile\PHPweb path)

더 자세한 정보는 위의 티스토리 블로그를 방문해주세요!

*만들다가 느낀거지만 클린하지 않은 &#127837;"스파게티 코드"&#127837;네요... &#128549;&#128549;
실습용으로는 적당한 것 같습니다.
초보자 이슈로 인해 양해부탁드립니다. 

### [Log in, Join] 로그인 및 회원가입 페이지 
![image](https://github.com/silver-liq9118/php_website_basic/assets/68416184/b1599500-3193-4a96-b77d-ef586051008a)

### [board page]
<image src="https://github.com/silver-liq9118/php_website_basic/assets/68416184/033f7567-509b-4b84-adf5-6ea7ae3fd3b3" width="400" height="200"/>

### [post write page]
<img src="https://github.com/silver-liq9118/php_website_basic/assets/68416184/ecc510a8-c6e1-4ac8-99ed-1b98e9bc1366.png"  width="400" height="400"/>


### [post view page]
<img src="https://github.com/silver-liq9118/php_website_basic/assets/68416184/22b5ce16-6e79-415f-91d0-5ebf9faea0d6.png"  width="400" height="400"/>









