<?php
include "db_conn.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['email']) && isset($_SESSION['username'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['title']) && isset($_POST['content'])) {
            $title = $_POST['title'];
            $content = $_POST['content'];
            $author = $_SESSION['username'];

            // Prepared Statement를 사용하여 SQL 인젝션 방지
            $stmt = $conn->prepare("INSERT INTO posts (title, content, author, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
            $stmt->bind_param("sss", $title, $content, $author);

            if ($stmt->execute()) {
                // 게시글 추가에 성공한 경우
                header("Location: board.php");
                exit();
            } else {
                // 게시글 추가에 실패한 경우
                include "write_failed.html";
            }

            $stmt->close();
        } else {
            // POST 요청에 title 또는 content가 없는 경우
            include "write_failed.html";
        }
    } else {
        // POST 요청이 아닌 경우
        include "write_failed.html";
    }
} else {
    include "access_failed.html";
    exit();
}

$conn->close();
?>


