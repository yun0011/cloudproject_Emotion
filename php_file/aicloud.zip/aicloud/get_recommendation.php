<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 입력된 데이터 받기
    $email = htmlspecialchars($_POST['email']);
    $tET 파라미터로 변환하여 리디렉션
    $query = http_build_query([
        'email' => $email,
        'type' => $type,
        'emotion' => $emotion,
        'movies' => $movies
    ]);
    header("Location: ?$query");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Emotion Analysis</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            padding: 20px;
            text-align: center;
        }
        h1 {
            color: #333;
        }
        form {
            margin-top: 20px;
        }
        input[type="text"], input[type="submit"] {
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        .movie-list {
            list-style-type: none;
            padding: 0;
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
        }
        .movie-list li {
            background-color: #fff;
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1>Emotion Analysis Input</h1>
    <?php if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['email'])): ?>
        <p>Email: <?php echo htmlspecialchars($_GET['email']); ?></p>
        <p>Type: <?php echo htmlspecialchars($_GET['type']); ?></p>
        <p>Emotion: <?php echo htmlspecialchars($_GET['emotion']); ?></p>
        <h2>Recommended Movies</h2>
        <ul class="movie-list">
            <?php
            $movies = json_decode($_GET['movies'], true);
            if (is_array($movies) && count($movies) > 0) {
                foreach ($movies as $movie) {
                    echo "<li>" . htmlspecialchars($movie) . "</li>";
                }
            } else {
                echo "<li>No movie recommendations available.</li>";
            }
            ?>
        </ul>
    <?php else: ?>
        <form action="" method="post">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required><br>
            <label for="type">Type:</label>
            <input type="text" id="type" name="type" required><br>
            <label for="emotion">Emotion:</label>
            <input type="text" id="emotion" name="emotion" required><br>
            <input type="submit" value="Submit">
        </form>
    <?php endif; ?>
</body>
</html>