<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>영화 추천 받기</title>
    <style>
        /* 영화추천받기 페이지 스타일 */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        .message {
            margin-bottom: 20px;
            font-size: 18px;
            color: #777;
        }
        .button-container {
            margin-top: 20px;
        }
        .button-container button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .button-container button:hover {
            background-color: #45a049;
        }
        /* 테이블 스타일 */
        table {
            width: 50%;
            border-collapse: collapse;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>영화 추천 받기</h1>
    <table>
        <tr>
            <th>영화 제목</th>
            <th>영화 URL</th>
        </tr>
        

        <?php
        include "db_conn.php";

        // 영화 정보를 가져오는 쿼리
        $sql = "SELECT movie_title, homepage FROM all_movies";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // 가져온 데이터를 반복문을 통해 출력
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row["movie_title"]."</td>
                        <td><a href='".$row["homepage"]."'>".$row["homepage"]."</a></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='2'>영화 정보가 없습니다.</td></tr>";
        }

        // MySQL 연결 종료
        $conn->close();
        ?>
    </table>
</body>
</html>
