<?php
include "db_conn.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['email']) && isset($_SESSION['username'])) {
    $email = $_SESSION['email'];
    $username = $_SESSION['username'];
    $type = $_SESSION['user_type'];}


     else {
    $email = "";
    $username = "";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    $postData = [
        "data" => [[$title, $content]]
    ];

    $apiUrl = 'https://func-20202010.azurewebsites.net/api/func?code=AdHeetQdRPpYVlNV8vUMNyb7RDxJJdnW4469NUJnBs6dAzFu3zWtuA%3D%3D';

    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($postData),
        ],
    ];

    $context  = stream_context_create($options);
    $response = file_get_contents($apiUrl, false, $context);

    if ($response === FALSE) {
        die('Error');
    }

    $result = json_decode($response, true);
    $emotion = implode(', ', $result['classes']);
    $emotion_result = [
        "emotion" => $emotion,
        "result" => $result['result'],
        "ment" => $result['ment']
    ];

    $stmt = $conn->prepare("INSERT INTO posts (title, created_at, updated_at, author, content, emotion) VALUES (?, NOW(), NOW(), ?, ?, ?)");
    $stmt->bind_param("ssss", $title, $username, $content, $emotion);

    if ($stmt->execute()) {
        $_SESSION['emotion_result'] = json_encode($emotion_result);
        header("Location: emotion_result.php");
        exit();
    } else {
        echo "일기 저장에 실패했습니다.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>오늘의 일기 쓰기</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3f3f3;
            padding: 20px;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .notice {
            color: #333;
            text-align: center;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            resize: vertical;
            font-family: Arial, sans-serif;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
        input[type="submit"], input[type="button"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>&#9997; 오늘의 일기 쓰기 &#9997;</h1>
    <div class="notice" name="notice" style="font-family: Arial, sans-serif;">&#9994; 오늘 있었던 일 솔직하게 털어놔요 &#10024;</div>
    <p></p>
    <div class="container">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title"></label>
                <input type="text" id="title" name="title" required placeholder="제목을 입력해주세요." style="font-family: Arial, sans-serif;">
            </div>
            <div class="form-group">
                <label for="content"></label>
                <textarea id="content" name="content" rows="20" required placeholder="내용을 입력해주세요." style="font-family: Arial, sans-serif;"></textarea>
            </div>
            <div class="button-group">
                <input type="submit" value="작성하기">
                <input type="button" value="뒤로가기" onclick="goToBoardPage()">
            </div>
        </form>
    </div>
</body>
</html>
<script>
    function goToBoardPage() {
        window.location.href = "board.php";
    }
</script>
