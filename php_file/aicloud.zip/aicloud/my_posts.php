<?php
include "db_conn.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    // 사용자 ID가 세션에 없으면 로그인 페이지로 리디렉션
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// 사용자가 작성한 게시물 목록을 가져옴
$sql = "SELECT id, title, author, created_at FROM posts WHERE author = '$userId'";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>마이페이지 게시판</title>
    <style>
        /* CSS 스타일링 */
    </style>
</head>
<body>
    <h1>마이페이지 게시판</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>제목</th>
            <th>작성자</th>
            <th>작성일</th>
        </tr>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['id']}</td>";
                echo "<td><a href='get_board_content.php?id={$row['id']}' class='post-link'>{$row['title']}</a></td>";
                echo "<td>{$row['author']}</td>";
                echo "<td>{$row['created_at']}</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>작성한 게시물이 없습니다.</td></tr>";
        }
        ?>
    </table>
</body>
</html>
